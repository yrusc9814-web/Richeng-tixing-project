<!-- codex-memory:template=task-refs:v1 -->

# 关键引用

只保留这个任务后续还会继续用到的关键索引。

## 引用

- 主画板：无
- 主节点：无
- 公共组件来源：`miniprogram/app.wxss`
- 素材路径：用户上传衣物图片，第一版通过微信云存储保存。
- 其他关键引用：
  - `产品文档/穿搭日记微信小程序_PRD_v1.5.docx`
  - `产品文档/穿搭日记微信小程序_PRD_v1.5_审核稿.docx`
  - `index.html` 既有 HTML 原型
  - `docs/dev-config.md`
  - `cloudfunctions/getWeather/index.js`
  - `miniprogram/pages/index/index.js`
  - `miniprogram/pages/wardrobe/wardrobe.js`
  - `miniprogram/pages/recommendation/recommendation.js`
  - 云环境 ID：`cloud1-d1gjweewr2740aa1f`
