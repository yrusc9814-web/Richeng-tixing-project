# 任务索引

- `chuanda-v15-mvp`：按 PRD v1.5 完成穿搭日记微信小程序第一版 MVP 开发。
