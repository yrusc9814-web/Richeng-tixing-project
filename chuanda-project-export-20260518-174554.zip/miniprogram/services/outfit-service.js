const localStore = require("../utils/outfit-store");

function canUseCloud() {
  return Boolean(wx.cloud && wx.cloud.callFunction);
}

function normalizeRecord(record) {
  return {
    id: record._id || record.id,
    date: record.date,
    top: record.top || null,
    bottom: record.bottom || null,
    shoes: record.shoes || null,
    accessory: record.accessory || null,
    note: record.note || "",
    weatherSnapshot: record.weatherSnapshot || null,
    createdAt: record.createdAt || 0,
    updatedAt: record.updatedAt || 0
  };
}

function callFunction(name, data) {
  return wx.cloud.callFunction({ name, data }).then(({ result }) => {
    if (!result || !result.ok) {
      const err = new Error((result && result.errorMessage) || "云函数调用失败");
      err.code = result && result.errorCode;
      throw err;
    }
    return result.data;
  });
}

async function getOutfits() {
  if (!canUseCloud()) return localStore.readOutfits();

  try {
    const data = await callFunction("getOutfitRecords", { page: 1, pageSize: 50 });
    const records = (data.items || []).map(normalizeRecord);
    localStore.writeOutfits(records);
    return records;
  } catch (err) {
    console.warn("getOutfitRecords cloud failed, fallback to local", err);
    return localStore.readOutfits();
  }
}

async function saveOutfit(payload) {
  if (!canUseCloud()) return localStore.createOutfit(payload);

  try {
    const data = await callFunction("saveOutfit", payload);
    const record = normalizeRecord(data);
    const cached = localStore.readOutfits().filter((oldRecord) => oldRecord.id !== record.id);
    localStore.writeOutfits([record, ...cached]);
    return record;
  } catch (err) {
    console.warn("saveOutfit cloud failed, fallback to local", err);
    return localStore.createOutfit(payload);
  }
}

async function deleteOutfit(record) {
  if (canUseCloud() && record && !String(record.id).startsWith("local_")) {
    try {
      await callFunction("deleteOutfitRecord", { id: record.id });
    } catch (err) {
      console.warn("deleteOutfitRecord cloud failed, fallback to local", err);
    }
  }

  return localStore.deleteOutfit(record.id);
}

module.exports = {
  getOutfits,
  saveOutfit,
  deleteOutfit
};
