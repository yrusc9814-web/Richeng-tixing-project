const wardrobeService = require("../../services/wardrobe-service");
const { ensurePrivacyAuthorized } = require("../../utils/privacy");

const TYPES = [
  { value: "top", label: "上衣" },
  { value: "bottom", label: "下装" },
  { value: "shoes", label: "鞋子" },
  { value: "accessory", label: "配饰" }
];

const emptyForm = () => ({
  type: "top",
  name: "",
  color: "",
  style: "",
  imageUrl: ""
});

Page({
  data: {
    types: TYPES,
    typeLabels: TYPES.map((type) => type.label),
    typeIndex: 0,
    activeType: "top",
    showForm: false,
    loading: false,
    saving: false,
    analyzing: false,
    form: emptyForm(),
    editingId: "",
    items: [],
    filteredItems: []
  },

  onShow() {
    this.loadItems();
  },

  async loadItems() {
    this.setData({ loading: true });
    const items = await wardrobeService.getWardrobe();
    this.setData({ items, loading: false }, this.refreshFilteredItems);
  },

  refreshFilteredItems() {
    const filteredItems = this.data.items.filter((item) => item.type === this.data.activeType);
    this.setData({ filteredItems });
  },

  changeType(event) {
    this.setData({ activeType: event.currentTarget.dataset.type }, this.refreshFilteredItems);
  },

  openForm() {
    const activeIndex = TYPES.findIndex((type) => type.value === this.data.activeType);
    this.setData({
      showForm: true,
      typeIndex: activeIndex >= 0 ? activeIndex : 0,
      editingId: "",
      form: {
        ...emptyForm(),
        type: this.data.activeType
      }
    });
  },

  editItem(event) {
    const id = event.currentTarget.dataset.id;
    const item = this.data.items.find((candidate) => candidate.id === id);
    if (!item) return;
    const typeIndex = TYPES.findIndex((type) => type.value === item.type);
    this.setData({
      showForm: true,
      editingId: item.id,
      typeIndex: typeIndex >= 0 ? typeIndex : 0,
      form: {
        type: item.type,
        name: item.name,
        color: item.color || "",
        style: item.style || "",
        imageUrl: item.imageFileId || item.imageUrl || "",
        imageFileId: item.imageFileId || ""
      }
    });
  },

  closeForm() {
    this.setData({ showForm: false, editingId: "", form: emptyForm() });
  },

  changeFormType(event) {
    const typeIndex = Number(event.detail.value);
    this.setData({
      typeIndex,
      "form.type": TYPES[typeIndex].value
    });
  },

  updateForm(event) {
    const field = event.currentTarget.dataset.field;
    this.setData({ [`form.${field}`]: event.detail.value });
  },

  async chooseImage() {
    try {
      await ensurePrivacyAuthorized();
    } catch (err) {
      wx.showToast({ title: "同意隐私政策后可选择图片", icon: "none" });
      return;
    }

    const handleFile = (file) => {
      if (!file) return;
      if (file.size && file.size > 5 * 1024 * 1024) {
        wx.showToast({ title: "图片不能超过5MB", icon: "none" });
        return;
      }
      this.setData({ "form.imageUrl": file.tempFilePath || file.path || file });
    };

    const fallbackChooseImage = () => {
      wx.chooseImage({
        count: 1,
        sizeType: ["compressed", "original"],
        sourceType: ["album", "camera"],
        success: (res) => {
          handleFile({
            tempFilePath: res.tempFilePaths && res.tempFilePaths[0],
            size: res.tempFiles && res.tempFiles[0] && res.tempFiles[0].size
          });
        },
        fail: (err) => {
          if (err && err.errMsg && err.errMsg.includes("cancel")) return;
          console.warn("chooseImage failed", err);
          wx.showToast({ title: (err && err.errMsg) || "没有选中图片", icon: "none" });
        }
      });
    };

    if (!wx.chooseMedia) {
      fallbackChooseImage();
      return;
    }

    wx.chooseMedia({
      count: 1,
      mediaType: ["image"],
      sourceType: ["album", "camera"],
      success: (res) => {
        handleFile(res.tempFiles && res.tempFiles[0]);
      },
      fail: (err) => {
        if (err && err.errMsg && err.errMsg.includes("cancel")) return;
        console.warn("chooseMedia failed, fallback to chooseImage", err);
        fallbackChooseImage();
      }
    });
  },

  async saveItem() {
    const form = {
      ...this.data.form,
      name: this.data.form.name.trim(),
      color: this.data.form.color.trim(),
      style: this.data.form.style.trim()
    };

    if (!form.name) {
      wx.showToast({ title: "请填写衣物名称", icon: "none" });
      return;
    }

    const isEditing = Boolean(this.data.editingId);
    this.setData({ saving: true });
    try {
      const item = isEditing
        ? await wardrobeService.updateClothing(this.data.editingId, form)
        : await wardrobeService.saveClothing(form);
      this.setData({
        activeType: item.type,
        showForm: false,
        editingId: "",
        form: emptyForm(),
        saving: false
      });
      this.loadItems();
      wx.showToast({ title: isEditing ? "已更新衣物" : "已加入衣橱", icon: "success" });
    } catch (err) {
      console.warn("save wardrobe item failed", err);
      this.setData({ saving: false });
      wx.showToast({ title: isEditing ? "更新失败" : "保存失败", icon: "none" });
    }
  },

  async analyzeImage() {
    if (!this.data.form.imageUrl) {
      wx.showToast({ title: "请先添加图片", icon: "none" });
      return;
    }

    this.setData({ analyzing: true });
    try {
      const result = await wardrobeService.analyzeClothing(this.data.form);
      const nextForm = {
        ...this.data.form,
        imageUrl: result.imageFileId || this.data.form.imageUrl,
        type: result.type || this.data.form.type,
        name: this.data.form.name || result.name || "",
        color: this.data.form.color || result.color || "",
        style: this.data.form.style || result.style || ""
      };
      const typeIndex = TYPES.findIndex((type) => type.value === nextForm.type);
      this.setData({
        form: nextForm,
        typeIndex: typeIndex >= 0 ? typeIndex : this.data.typeIndex,
        analyzing: false
      });
      wx.showToast({ title: "分析完成", icon: "success" });
    } catch (err) {
      this.setData({ analyzing: false });
      wx.showToast({ title: "AI分析失败，可手动填写", icon: "none" });
    }
  },

  deleteItem(event) {
    const id = event.currentTarget.dataset.id;
    const item = this.data.items.find((candidate) => candidate.id === id);
    if (!item) return;
    wx.showModal({
      title: "删除衣物",
      content: "删除后暂时不能恢复，确认删除吗？",
      success: async (res) => {
        if (!res.confirm) return;
        const items = await wardrobeService.deleteClothing(item);
        this.setData({ items }, this.refreshFilteredItems);
      }
    });
  }
});
