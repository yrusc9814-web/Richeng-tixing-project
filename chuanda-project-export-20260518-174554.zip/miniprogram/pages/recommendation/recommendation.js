const wardrobeService = require("../../services/wardrobe-service");
const outfitService = require("../../services/outfit-service");

const TAGS = ["日常简约", "清爽通勤", "轻松周末"];

function shuffle(items) {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function pickByType(items, type) {
  return items.filter((item) => item.type === type);
}

function todayStr() {
  const d = new Date();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const date = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${month}-${date}`;
}

Page({
  data: {
    items: [],
    counts: {
      top: 0,
      bottom: 0,
      shoes: 0
    },
    loading: false,
    results: []
  },

  async onShow() {
    this.setData({ loading: true });
    const items = await wardrobeService.getWardrobe();
    this.setData({
      loading: false,
      items,
      counts: {
        top: pickByType(items, "top").length,
        bottom: pickByType(items, "bottom").length,
        shoes: pickByType(items, "shoes").length
      }
    });
    this.generate();
  },

  generate() {
    const items = this.data.items;
    if (!items.length) {
      this.setData({ results: [] });
      return;
    }

    const tops = shuffle(pickByType(items, "top"));
    const bottoms = shuffle(pickByType(items, "bottom"));
    const shoes = shuffle(pickByType(items, "shoes"));
    const accessories = shuffle(pickByType(items, "accessory"));

    const results = [0, 1, 2].map((idx) => {
      const top = tops[idx % Math.max(tops.length, 1)] || null;
      const bottom = bottoms[idx % Math.max(bottoms.length, 1)] || null;
      const shoe = shoes[idx % Math.max(shoes.length, 1)] || null;
      const accessory = accessories[idx % Math.max(accessories.length, 1)] || null;
      const missing = [
        !top ? "上衣" : "",
        !bottom ? "下装" : "",
        !shoe ? "鞋子" : ""
      ].filter(Boolean);

      return {
        id: `rec_${Date.now()}_${idx}`,
        top,
        bottom,
        shoes: shoe,
        accessory,
        tag: TAGS[idx],
        reason: missing.length
          ? `当前衣橱缺少${missing.join("、")}，先用已有单品生成部分搭配。`
          : "颜色和品类组合完整，适合作为今天的基础穿搭。"
      };
    });

    this.setData({ results });
  },

  goWardrobe() {
    wx.switchTab({ url: "/pages/wardrobe/wardrobe" });
  },

  async saveRecommendation(event) {
    const index = Number(event.currentTarget.dataset.index);
    const result = this.data.results[index];
    if (!result) return;

    await outfitService.saveOutfit({
      date: todayStr(),
      top: result.top,
      bottom: result.bottom,
      shoes: result.shoes,
      accessory: result.accessory,
      note: result.tag
    });

    wx.showToast({ title: "已记录今日穿搭", icon: "success" });
  }
});
